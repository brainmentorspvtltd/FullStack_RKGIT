// console.log('Hello Node JS');
// console.log('Hi Node JS');
// Sync - Blocking Code
// Async Code
//function(__filename, require, __dirname){
var w = 100;
const fs = require('fs');
console.log('start reading a File....');
// writeFile , rename, copy, directory
fs.readFile(__filename, (err, content)=>{
    if(err){
        console.log('Error is ',err);
    }
    else{
        console.log(content.toString());
    }
}); // Async (Non Blocking)
console.log('End reading a File....');
//}