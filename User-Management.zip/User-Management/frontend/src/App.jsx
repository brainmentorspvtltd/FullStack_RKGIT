import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import IndexPage from "./pages/IndexPage";
import PageNotFound from "./pages/404";
import LoginPage from "./pages/LoginPage";
import AdminDashboard from "./pages/AdminDashboard";
import Users from "./pages/Users";
import Roles from "./pages/Roles";
import Permissions from "./pages/Permissions";
import ProfilePage from "./pages/ProfilePage";
import isLogin  from "./utils/isLogin";
export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={isLogin ? <AdminDashboard /> : <IndexPage />}/>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/dashboard" element={isLogin ? <AdminDashboard /> : <Navigate to="/login" replace />}/>
        <Route path="/users" element={isLogin ? <Users /> : <Navigate to="/login" replace />}/>
        <Route path="/roles" element={isLogin ? <Roles /> : <Navigate to="/login" replace />}/>
        <Route path="/permissions" element={ isLogin ? <Permissions /> : <Navigate to="/login" replace />}/>
        <Route path="/profile" element={isLogin ? <ProfilePage /> : <Navigate to="/login" replace />}/>
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </Router>
  );
}
