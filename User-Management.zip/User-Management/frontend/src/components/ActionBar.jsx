import React, { useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const ActionBar = ({ roles, permissions }) => {
  const currentPagePath = window.location.pathname;
  const [searchText, setSearchText] = useState("");
  const [isUserDialog, setUserDialogOpen] = useState(false);
  const [isRolesDialog, setRoleDialogOpen] = useState(false);
  const [isPermissionDialog, setPermissionDialogOpen] = useState(false);

  const createUser = async () => {
    try {
      const newUser = await axios.post("/users/create-user");
      const users = newUser.data;
      console.log(users);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  const handleSearch = () => {
    // permissions.filter((permission) => permission.name.includes(searchText));
    // Perform search logic or any other desired action
    // console.log("Searching for:", searchText);
    toast.info("Searching for:", searchText, {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: true,
      progress: undefined,
      theme: "dark",
    });
  };

  const handleInputChange = (event) => {
    setSearchText(event.target.value);
  };

  // const searchedData = {
  //   nodes: permissions.filter((permission) =>
  //     permission.name.includes(searchText)
  //   ),
  // };

  const handleAddNew = () => {
    if (currentPagePath === "/users") setUserDialogOpen(true);
    else if (currentPagePath === "/roles") setRoleDialogOpen(true);
    else if (currentPagePath === "/permissions") setPermissionDialogOpen(true);
  };

  const handleClose = () => {
    setUserDialogOpen(false);
    setRoleDialogOpen(false);
    setPermissionDialogOpen(false);
  };

  return (
    <>
      <ToastContainer />
      <div className="action-bar container">
        <input
          type="text"
          className="search-field"
          placeholder="Search..."
          value={searchText}
          onChange={handleInputChange}
        />
        <button className="action-button" onClick={handleSearch}>
          Go
        </button>
        <button className="add-new-button" onClick={handleAddNew}>
          ADD NEW
        </button>

        {isUserDialog && (
          <div id="popupForm" style={{ display: "block" }}>
            <h2>Create New User</h2>
            <form>
              <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input type="text" id="name" name="name" required />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input type="email" id="email" name="email" required />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input type="password" id="password" name="password" required />
              </div>

              <div className="form-group">
                <label htmlFor="role">Role:</label>
                <select id="role" name="roleID" required>
                  {roles.map((role) => (
                    <option key={role._id} value={role._id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="isActive">Active Status:</label>
                <select id="isActive" name="isActive" required>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>

              <div className="form-actions">
                <button type="submit" onClick={createUser}>
                  Submit
                </button>
                <button type="button" id="close_button" onClick={handleClose}>
                  Close
                </button>
              </div>
            </form>
          </div>
        )}
        {isRolesDialog && (
          <div id="popupForm" style={{ display: "block" }}>
            <h2>Create New Role</h2>
            <form action="#" method="POST">
              <div className="form-group">
                <label htmlFor="name">Role Name:</label>
                <input type="text" id="name" name="name" required />
              </div>

              <div className="form-group">
                <label htmlFor="permission">Allowed Permissions:</label>
                <select id="permission" name="permissionID" required>
                  {permissions.map((permission) => (
                    <option key={permission._id} value={permission._id}>
                      {permission.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-actions">
                <button type="submit">Submit</button>
                <button type="button" id="close_button" onClick={handleClose}>
                  Close
                </button>
              </div>
            </form>
          </div>
        )}
        {isPermissionDialog && (
          <div id="popupForm" style={{ display: "block" }}>
            <h2>Create permission</h2>
            <form action="#" method="POST">
              <div className="form-group">
                <label htmlFor="name">Permission Name:</label>
                <input type="text" id="name" name="name" required />
              </div>

              <div className="form-group">
                <label htmlFor="description">Description:</label>
                <input
                  type="text"
                  id="description"
                  name="description"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="isActive">Active Status:</label>
                <select id="isActive" name="isActive" required>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>

              <div className="form-actions">
                <button type="submit">Submit</button>
                <button type="button" id="close_button" onClick={handleClose}>
                  Close
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
      <table data={handleSearch}></table>
    </>
  );
};

export default ActionBar;
