import React from "react";

const AddUserButton = () => {
  return (
    <button id="createUser" className="createUser btn btn-primary">
      ADD USER
    </button>
  );
};

export default AddUserButton;
