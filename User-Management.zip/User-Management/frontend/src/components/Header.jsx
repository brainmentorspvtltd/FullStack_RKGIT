import React, { useState } from "react";
import axios from "axios";
import "../assets/CSS/header.css";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Header = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState(null);
  const getAllUsers = async () => {
    try {
      const response = await axios.get("/users/all-users");
      setUsers(response.data);

      navigate("/users", { state: users });
    } catch (error) {
      toast.error(error.response.data.message, {
        position: "bottom-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
        progress: undefined,
        theme: "dark",
      });
      navigate("/login");
      // toast.error(error.response.data.message, {
      //   position: toast.POSITION.BOTTOM_CENTER,
      //   autoClose: 3000, //3 seconds
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: true,
      // });
      // alert(error.response.data.message);
    }
  };

  const getAllRoles = async () => {
    try {
      const response = await axios.get("/roles/all-roles");
      const roles = response.data;
      console.log(roles);
      navigate("/roles", { state: roles });
      // TODO: Handle the retrieved users in your component's state or render them in the UI
    } catch (error) {
      console.log(error);
    }
  };
  const handleLogout = async () => {
    try {
      const response = await axios.post("/users/logout");
      if (response.status === 200) {
        console.log("Logged out successfully");
        navigate("/login");
      } else {
        console.log("Logout failed");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <ToastContainer />
      <nav className="navbar navbar-expand navbar-dark bg-dark container">
        <a className="navbar-brand" href="/dashboard">
          <img
            src="https://seeklogo.com/images/G/google-admin-logo-A220604CE8-seeklogo.com.png"
            width="30"
            height="30"
            className="d-inline-block align-top"
            alt=""
          />
          ADMIN PANEL
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item active">
              <button className="nav-link " onClick={getAllUsers}>
                Users
              </button>
            </li>
            <li className="nav-item">
              <button className="nav-link " onClick={getAllRoles}>
                Roles
              </button>
            </li>

            <li className="nav-item">
              <Link className="nav-link " to="/permissions">
                Permissions
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link " to="/profile">
                Profile
              </Link>
            </li>

            {/* <li className="nav-item">
            <button
              className="nav-link"
              onMouseEnter={handleProfileHover}
              onMouseLeave={handleProfileLeave}
            >
              Profile
            </button>
            {showUserDetails && (
              <div className="user-details">
                <p>Name: {userDetails.name}</p>
                <p>Email: {userDetails.email}</p>
                <p>Role: {userDetails.role}</p>
              </div>
            )}
            </li>*/}
            <li className="nav-item">
              <button
                className="nav-link btn btn-danger"
                onClick={handleLogout}
              >
                Logout
              </button>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
};

export default Header;
