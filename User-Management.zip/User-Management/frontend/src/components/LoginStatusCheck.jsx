import React, { useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const LoginStatusCheck = ({ children }) => {
  const navigate = useNavigate();

  useEffect(() => {
    checkLoginStatus();
  });

  const checkLoginStatus = async () => {
    console.log("CHECKING LOGIN");
    try {
      const response = await axios.get("/users/check-login");
      if (!response.data.loggedIn) {
        navigate("/login"); // Redirect to login if not logged in
      }
    } catch (error) {
      console.log(error);
    }
  };

  return <>{children}</>;
};

export default LoginStatusCheck;
