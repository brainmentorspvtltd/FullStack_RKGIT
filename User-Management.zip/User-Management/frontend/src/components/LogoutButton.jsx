import React from "react";

const LogoutButton = () => {
  return (
    <button id="logoutButton" className="logout-button btn btn-danger">
      Logout
    </button>
  );
};

export default LogoutButton;
