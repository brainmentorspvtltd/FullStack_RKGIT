import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen, faTrash } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import "../assets/CSS/dashboad.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UserTable = ({ permissions }) => {
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [updatedPermission, setUpdatedPermission] = useState({
    id: "",
    name: "",
    description: "",
    isActive: "",
  });

  const [deletedPermission, setDeletedPermission] = useState({
    id: "",
  });

  const updatePermission = (permission) => {
    setUpdatedPermission(permission);
    setUpdateDialogOpen(true);
  };

  const deletePermission = (permissionId) => {
    setDeletedPermission(permissionId);
    setDeleteDialogOpen(true);
    // Handle logic to delete the permission with the given permissionId
    console.log(`Deleting permission with ID: ${permissionId}`);
  };

  // const handleInputChange = (e) => {
  //   const { name, value, type, checked } = e.target;
  //   const inputValue = type === "checkbox" ? checked : value;
  //   setUpdatedPermission((prevPermission) => ({
  //     ...prevPermission,
  //     [name]: inputValue,
  //   }));
  // };
  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    let inputValue;

    if (type === "checkbox") {
      inputValue = e.target.checked;
    } else if (type === "radio") {
      inputValue = value === "true";
    } else {
      inputValue = value;
    }

    setUpdatedPermission((prevPermission) => ({
      ...prevPermission,
      [name]: inputValue,
    }));
  };

  const submitUpdate = async () => {
    try {
      const response = await axios.put(
        "permissions/update-permission",
        updatedPermission
      );
      if (response.status === 200) {
        toast.success("Successfully Updated", {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
        setUpdateDialogOpen(false);
        // window.location.reload();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const deletePermanentaly = async () => {
    try {
      const response = await axios.delete(
        `permissions/delete-permission/${deletedPermission}`
      );
      if (response.status === 200) {
        alert("Successfully deleted");
        setUpdateDialogOpen(false);
        // window.location.reload();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const closeDialog = () => {
    setDeleteDialogOpen(false);
    setUpdateDialogOpen(false);
  };

  return (
    <>
      <ToastContainer />
      <div
        className="tab-content container"
        id="users"
        style={{ display: "block" }}
      >
        <table>
          <thead>
            <tr>
              <th>Permission ID</th>
              <th>Permission Name</th>
              <th>Description</th>
              <th>Is Active</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {permissions.map((permission) => (
              <tr key={permission.id}>
                <td>{permission.id}</td>
                <td>{permission.name}</td>
                <td>{permission.description}</td>
                <td>{permission.isActive.toString()}</td>
                <td>
                  <div className="crud-buttons">
                    <button
                      id={`editPermission-${permission.id}`}
                      onClick={() => updatePermission(permission)}
                    >
                      <FontAwesomeIcon icon={faPen} />
                    </button>
                    <button
                      id={`deletePermission-${permission.id}`}
                      onClick={() => deletePermission(permission.id)}
                    >
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {updateDialogOpen && (
          <div className="dialog">
            <div className="dialog-content">
              <h3>Edit Permission</h3>
              <form>
                <label htmlFor="permissionName">Name:</label>
                <input
                  type="text"
                  id="permissionName"
                  name="name"
                  value={updatedPermission.name}
                  onChange={handleInputChange}
                />
                <label htmlFor="permissionDescription">Description:</label>
                <textarea
                  id="permissionDescription"
                  name="description"
                  value={updatedPermission.description}
                  onChange={handleInputChange}
                />
                <label>Is Active:</label>
                <div>
                  <label>
                    <input
                      type="radio"
                      name="isActive"
                      value="true"
                      checked={updatedPermission.isActive === true}
                      onChange={handleInputChange}
                    />
                    True
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="isActive"
                      value="false"
                      checked={updatedPermission.isActive === false}
                      onChange={handleInputChange}
                    />
                    False
                  </label>
                </div>
              </form>
              <button onClick={submitUpdate}>Update</button>
              <button onClick={closeDialog}>Cancel</button>
            </div>
          </div>
        )}
        {deleteDialogOpen && (
          <div className="dialog">
            <div className="dialog-content">
              <h3>Delete Permanentaly?</h3>
              <h5>{deletedPermission}</h5>
              <h6>This action can't be undone.</h6>
              <button onClick={deletePermanentaly}>Yes</button>
              <button onClick={closeDialog}>Cancel</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default UserTable;
