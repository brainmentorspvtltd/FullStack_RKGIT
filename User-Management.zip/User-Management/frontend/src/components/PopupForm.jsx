import React from "react";

const PopupForm = ({ userRoles }) => {
  return (
    <div id="popupForm" style={{ display: "none" }}>
      <h2>Create User</h2>
      <form action="/register" method="POST">
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input type="text" id="username" name="username" required />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" required />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" required />
        </div>

        <div className="form-group">
          <label htmlFor="role">Role:</label>
          <select id="role" name="roleID" required>
            {userRoles.map((role) => (
              <option key={role._id} value={role._id}>
                {role.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="isActive">Active Status:</label>
          <select id="isActive" name="isActive" required>
            <option value="true">Active</option>
            <option value="false">Inactive</option>
          </select>
        </div>

        <div className="form-actions">
          <button type="submit">Submit</button>
          <button type="button" id="close_button">Close</button>
        </div>
      </form>
    </div>
  );
};

export default PopupForm;
