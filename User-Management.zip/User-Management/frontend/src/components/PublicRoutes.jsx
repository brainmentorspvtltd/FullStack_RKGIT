import { Route } from "react-router-dom";
import AdminDashboard from "../pages/AdminDashboard";
import ProfilePage from "../pages/ProfilePage";
import Permissions from "./pages/Permissions";
import Users from "./pages/Users";
import Roles from "./pages/Roles";
const PrivateRoutes = () => {
  return (
    <>
      <Route path="/" element={<AdminDashboard />} />
      <Route path="/dashboard" element={<AdminDashboard />} />
      <Route path="/users" element={<Users />} />
      <Route path="/roles" element={<Roles />} />
      <Route path="/permissions" element={<Permissions />} />
      <Route path="/profile" element={<ProfilePage />} />
    </>
  );
};

export default PrivateRoutes;
