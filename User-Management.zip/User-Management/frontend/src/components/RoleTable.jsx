// import React from "react";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faPen, faTrash } from "@fortawesome/free-solid-svg-icons";
// import getPermissionsName from "../utils/getPermissionName";
// import "../assets/CSS/dashboad.css";

// const RoleTable = ({ roles }) => {
//   let permissionsNames = [];
//   const PermissionNames = async (roles) => {
//     for await (let permission of roles) {
//       let permissionName = getPermissionsName(permission);
//       permissionsNames.push(permissionName);
//     }
//     console.log("THIS IS THE FINAL LIST", permissionsNames);
//     return permissionsNames;
//   };
//   return (
//     <div
//       className="tab-content container"
//       id="roles"
//       style={{ display: "block" }}
//     >
//       <table>
//         <thead>
//           <tr>
//             <th>Role ID</th>
//             <th>Role Name</th>
//             <th>Allowed Permissions</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {roles.map((role) => (
//             <tr key={role.id}>
//               <td>{role.id}</td>
//               <td>{role.name}</td>
//               <td>
//                 <b>
//                   {PermissionNames(role.permissions).map((name, index) => (
//                     <span key={index}>{name}</span>
//                   ))}
//                 </b>
//               </td>

//               <td>
//                 <div className="crud-buttons">
//                   <button id="editRole">
//                     <FontAwesomeIcon icon={faPen} />
//                   </button>
//                   <button id="deleteRole">
//                     <FontAwesomeIcon icon={faTrash} />
//                   </button>
//                 </div>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default RoleTable;

import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen, faTrash } from "@fortawesome/free-solid-svg-icons";
import getPermissionsName from "../utils/getPermissionName";
import "../assets/CSS/dashboad.css";

const RoleTable = ({ roles }) => {
  const [permissionNames, setPermissionNames] = useState([]);

  useEffect(() => {
    const fetchPermissionNames = async () => {
      const names = await Promise.all(
        roles.map((role) => {
          return Promise.all(role.permissions.map(getPermissionsName));
        })
      );
      setPermissionNames(names);
    };

    fetchPermissionNames();
  }, [roles]);

  return (
    <div
      className="tab-content container"
      id="roles"
      style={{ display: "block" }}
    >
      <table>
        <thead>
          <tr>
            <th>Role ID</th>
            <th>Role Name</th>
            <th>Allowed Permissions</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {roles.map((role, index) => (
            <tr key={role.id}>
              <td>{role.id}</td>
              <td>{role.name}</td>
              <td>
                  {permissionNames[index]?.map((name, innerIndex) => (
                    <span key={innerIndex}>{name+ ", "}</span>
                  ))}
              </td>
              <td>
                <div className="crud-buttons">
                  <button id="editRole">
                    <FontAwesomeIcon icon={faPen} />
                  </button>
                  <button id="deleteRole">
                    <FontAwesomeIcon icon={faTrash} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RoleTable;
