import React from "react";

const TabContainer = () => {
  return (
    <div className="tab-container">
      <button className="tab active">Users</button>
      <button className="tab">Roles</button>
      <button className="tab">Permissions</button>
    </div>
  );
};

export default TabContainer;
