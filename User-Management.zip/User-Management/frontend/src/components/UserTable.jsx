// import React, { useState } from "react";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { ToastContainer, toast } from "react-toastify";
// import {
//   faPen,
//   faTrash,
//   faTriangleExclamation,
// } from "@fortawesome/free-solid-svg-icons";
// import axios from "axios";
// import getRoleName from "../utils/getRoleName";
// import "../assets/CSS/dashboad.css";

// const UserTable = ({ users }) => {
//   const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
//   const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
//   const [updatedUser, setUpdatedUser] = useState({
//     id: "",
//     name: "",
//     description: "",
//     isActive: "",
//   });
//   const notify = () => {
//     toast("Default Notification !");

//     toast.success("Success Notification !", {
//       position: toast.POSITION.BOTTOM_CENTER,
//     });

//     toast.error("Error Notification !", {
//       position: toast.POSITION.BOTTOM_CENTER,
//     });

//     toast.warn("Warning Notification !", {
//       position: toast.POSITION.BOTTOM_CENTER,
//     });

//     toast.info("Info Notification !", {
//       position: toast.POSITION.BOTTOM_CENTER,
//     });
//   };
//   const [deletedUser, setDeletedUser] = useState({
//     id: "",
//   });
//   const updateUser = (permission) => {
//     setUpdatedUser(permission);
//     setUpdateDialogOpen(true);
//   };

//   const handleInputChange = (e) => {
//     const { name, value, type } = e.target;
//     let inputValue;

//     if (type === "checkbox") {
//       inputValue = e.target.checked;
//     } else if (type === "radio") {
//       inputValue = value === "true";
//     } else {
//       inputValue = value;
//     }

//     setUpdatedUser((prevPermission) => ({
//       ...prevPermission,
//       [name]: inputValue,
//     }));
//   };

//   const submitUpdate = async () => {
//     try {
//       const response = await axios.put("users/update-user", updatedUser);
//       if (response.status === 200) {
//         <ToastContainer />;

//         // alert("Successfully updated");
//         setUpdateDialogOpen(false);
//         // window.location.reload();
//       }
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   const deletePermanentaly = async () => {
//     try {
//       const response = await axios.delete(`users/delete-user/${deletedUser}`);
//       if (response.status === 200) {
//         alert("Successfully deleted");
//         setUpdateDialogOpen(false);
//         setDeleteDialogOpen(false);
//         // window.location.reload();
//       }
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   const closeDialog = () => {
//     setDeleteDialogOpen(false);
//     setUpdateDialogOpen(false);
//   };

//   const deleteUser = (userId, name) => {
//     setDeletedUser(userId);
//     setDeleteDialogOpen(true);
//     // Handle logic to delete the permission with the given permissionId
//     console.log(`Deleting permission with ID: ${userId}`);
//   };
//   return (
//     <div
//       className="tab-content container"
//       id="users"
//       style={{ display: "block" }}
//     >
//       <table>
//         <thead>
//           <tr>
//             <th>User ID</th>
//             <th>Username</th>
//             <th>User's email</th>
//             <th>User's role</th>
//             <th>Is Active</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {users.map((user) => (
//             <tr key={user.id}>
//               <td>{user.id}</td>
//               <td>{user.name}</td>
//               <td>{user.email}</td>
//               <td>{getRoleName(user.role)}</td>
//               <td>{user.isActive.toString()}</td>
//               <td>
//                 <div className="crud-buttons">
//                   <button
//                     id={`editUser-${user.id}`}
//                     onClick={() => updateUser(user)}
//                   >
//                     <FontAwesomeIcon icon={faPen} />
//                   </button>
//                   <button
//                     id={`deletePermission-${user.id}`}
//                     onClick={() => deleteUser(user.id, user.name)}
//                   >
//                     <FontAwesomeIcon icon={faTrash} />
//                   </button>
//                 </div>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//       {updateDialogOpen && (
//         <div className="dialog">
//           <div className="dialog-content">
//             <h3>Edit User Details</h3>
//             <form>
//               <label htmlFor="permissionName">Name:</label>
//               <input
//                 type="text"
//                 id="userName"
//                 name="name"
//                 value={updatedUser.name}
//                 onChange={handleInputChange}
//               />
//               <label htmlFor="permissionName">Email:</label>
//               <input
//                 type="email"
//                 id="userEmail"
//                 name="email"
//                 value={updatedUser.email}
//                 onChange={handleInputChange}
//               />
//               <label htmlFor="permissionName">Role:</label>
//               <input
//                 type="text"
//                 id="userRole"
//                 name="role"
//                 value={updatedUser.role}
//                 onChange={handleInputChange}
//               />
//               <label>Is Active:</label>
//               <div>
//                 <label>
//                   <input
//                     type="radio"
//                     name="isActive"
//                     value="true"
//                     checked={updatedUser.isActive === true}
//                     onChange={handleInputChange}
//                   />
//                   True
//                 </label>
//                 <label>
//                   <input
//                     type="radio"
//                     name="isActive"
//                     value="false"
//                     checked={updatedUser.isActive === false}
//                     onChange={handleInputChange}
//                   />
//                   False
//                 </label>
//               </div>
//             </form>
//             <button onClick={submitUpdate}>Update</button>
//             <button onClick={closeDialog}>Cancel</button>
//           </div>
//         </div>
//       )}
//       {deleteDialogOpen && (
//         <div className="dialog">
//           <div className="dialog-content">
//             <h4 style={{ color: "grey" }}>
//               Delete <b style={{ color: "black" }}>{deletedUser}</b> forever?
//             </h4>
//             <h6 style={{ color: "red" }}>
//               <FontAwesomeIcon icon={faTriangleExclamation} />
//               This action can't be undone.
//             </h6>
//             <button onClick={deletePermanentaly}>Yes</button>
//             <button onClick={closeDialog}>Cancel</button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default UserTable;

import React, { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { ToastContainer, toast } from "react-toastify";
import {
  faPen,
  faTrash,
  faTriangleExclamation,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import getRoleName from "../utils/getRoleName";
import "../assets/CSS/dashboad.css";

const UserTable = ({ users }) => {
  const [resolvedUsers, setResolvedUsers] = useState([]);

  useEffect(() => {
    const resolveUsers = async () => {
      const resolvedUsers = await Promise.all(
        users.map(async (user) => {
          const resolvedRoleName = await getRoleName(user.role);
          return { ...user, roleName: resolvedRoleName };
        })
      );
      setResolvedUsers(resolvedUsers);
    };

    resolveUsers();
  }, [users]);

  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [updatedUser, setUpdatedUser] = useState({
    id: "",
    name: "",
    description: "",
    isActive: "",
  });
  const notify = () => {
    toast("Default Notification !");

    toast.success("Success Notification !", {
      position: toast.POSITION.BOTTOM_CENTER,
    });

    toast.error("Error Notification !", {
      position: toast.POSITION.BOTTOM_CENTER,
    });

    toast.warn("Warning Notification !", {
      position: toast.POSITION.BOTTOM_CENTER,
    });

    toast.info("Info Notification !", {
      position: toast.POSITION.BOTTOM_CENTER,
    });
  };
  const [deletedUser, setDeletedUser] = useState({
    id: "",
  });
  const updateUser = (permission) => {
    setUpdatedUser(permission);
    setUpdateDialogOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    let inputValue;

    if (type === "checkbox") {
      inputValue = e.target.checked;
    } else if (type === "radio") {
      inputValue = value === "true";
    } else {
      inputValue = value;
    }

    setUpdatedUser((prevPermission) => ({
      ...prevPermission,
      [name]: inputValue,
    }));
  };

  const submitUpdate = async () => {
    try {
      const response = await axios.put("users/update-user", updatedUser);
      if (response.status === 200) {
        <ToastContainer />;

        // alert("Successfully updated");
        setUpdateDialogOpen(false);
        // window.location.reload();
      }
    } catch (error) {
      console.log(error);
    }
  };
  const deletePermanentaly = async () => {
    try {
      const response = await axios.delete(`users/delete-user/${deletedUser}`);
      if (response.status === 200) {
        alert("Successfully deleted");
        setUpdateDialogOpen(false);
        setDeleteDialogOpen(false);
        // window.location.reload();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const closeDialog = () => {
    setDeleteDialogOpen(false);
    setUpdateDialogOpen(false);
  };

  const deleteUser = (userId, name) => {
    setDeletedUser(userId);
    setDeleteDialogOpen(true);
    // Handle logic to delete the permission with the given permissionId
    console.log(`Deleting permission with ID: ${userId}`);
  };

  return (
    <div
      className="tab-content container"
      id="users"
      style={{ display: "block" }}
    >
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>Username</th>
            <th>User's email</th>
            <th>User's role</th>
            <th>Is Active</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {resolvedUsers.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.roleName}</td>
              <td>{user.isActive.toString()}</td>
              <td>
                <div className="crud-buttons">
                  <button
                    id={`editUser-${user.id}`}
                    onClick={() => updateUser(user)}
                  >
                    <FontAwesomeIcon icon={faPen} />
                  </button>
                  <button
                    id={`deletePermission-${user.id}`}
                    onClick={() => deleteUser(user.id, user.name)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {updateDialogOpen && (
        <div className="dialog">
          <div className="dialog-content">
            <h3>Edit User Details</h3>
            <form>
              <label htmlFor="permissionName">Name:</label>
              <input
                type="text"
                id="userName"
                name="name"
                value={updatedUser.name}
                onChange={handleInputChange}
              />
              <label htmlFor="permissionName">Email:</label>
              <input
                type="email"
                id="userEmail"
                name="email"
                value={updatedUser.email}
                onChange={handleInputChange}
              />
              <label htmlFor="permissionName">Role:</label>
              <input
                type="text"
                id="userRole"
                name="role"
                value={updatedUser.role}
                onChange={handleInputChange}
              />
              <label>Is Active:</label>
              <div>
                <label>
                  <input
                    type="radio"
                    name="isActive"
                    value="true"
                    checked={updatedUser.isActive === true}
                    onChange={handleInputChange}
                  />
                  True
                </label>
                <label>
                  <input
                    type="radio"
                    name="isActive"
                    value="false"
                    checked={updatedUser.isActive === false}
                    onChange={handleInputChange}
                  />
                  False
                </label>
              </div>
            </form>
            <button onClick={submitUpdate}>Update</button>
            <button onClick={closeDialog}>Cancel</button>
          </div>
        </div>
      )}
      {deleteDialogOpen && (
        <div className="dialog">
          <div className="dialog-content">
            <h4 style={{ color: "grey" }}>
              Delete <b style={{ color: "black" }}>{deletedUser}</b> forever?
            </h4>
            <h6 style={{ color: "red" }}>
              <FontAwesomeIcon icon={faTriangleExclamation} />
              This action can't be undone.
            </h6>
            <button onClick={deletePermanentaly}>Yes</button>
            <button onClick={closeDialog}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserTable;
