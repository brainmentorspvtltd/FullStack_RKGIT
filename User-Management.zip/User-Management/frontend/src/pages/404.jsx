export default function ErrorPage() {
  return (
    <div id="error-page">
      <h1>Page not Found</h1>
    </div>
  );
}
