import React from "react";

const ServerError = () => {
  return <div>ServerError</div>;
};

export default ServerError;
