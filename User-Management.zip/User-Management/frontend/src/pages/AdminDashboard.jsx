import React from "react";
import Header from "../components/Header";
import { useLocation } from "react-router-dom";
const AdminDashboard = () => {
  const location = useLocation();
  const userDetails = location.state;
  return (
    <div className="container">
      <div className="row">
        <Header userDetails={userDetails} />
        <h1 style={{ textAlign: "center" }}>Welcome</h1>
      </div>
    </div>
  );
};

export default AdminDashboard;
