import React from "react";
import { useNavigate } from "react-router-dom";
const IndexPage = () => {
  const navigate = useNavigate();
  const handleLogin = () => {
    navigate("/login");
  };
  return (
    <div>
      <div style={{ textAlign: "center" }}>
        <h1>Welcome to the User Management</h1>
        <button onClick={handleLogin}>Login</button>
      </div>
    </div>
  );
};

export default IndexPage;
