import React from "react";
import axios from "axios";
import PermissionTable from "../components/PermissionTable";
import Layout from "../components/Layout";
import ActionBar from "../components/ActionBar";
import { FidgetSpinner } from "react-loader-spinner";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const PermissionsPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, seterror] = React.useState(null);
  const [permissions, setPermissions] = React.useState(null);

  React.useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await axios
        .get("/permissions/all-permissions")
        .then((response) => {
          setPermissions(response.data);
        })
        .catch((error) => {
          seterror(error);
        })
        .finally(() => {
          setLoading(false);
        });
      // catch (err) {
      //   console.log("====================================");
      //   console.log("thsi is the error in the permissions table", err);
      //   console.log("====================================");
      //   seterror(err);
      // } finally {
      //   setLoading(false);
      // }
    };

    loadData();
  }, []);

  // const location = useLocation();
  // const permissions = location.state;
  if (loading) {
    return (
      <Layout>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <FidgetSpinner
            visible={true}
            height="80"
            width="80"
            ariaLabel="dna-loading"
            wrapperStyle={{}}
            wrapperClass="dna-wrapper"
            ballColors={["#ff0000", "#00ff00", "#0000ff"]}
            backgroundColor="#F4442E"
          />
        </div>
      </Layout>
    );
  }
  if (error) {
    return (
      <Layout>
        {toast.error(error.response.data.message, {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          draggable: true,
          progress: undefined,
          theme: "dark",
        })}
      </Layout>
    );
  }
  return (
    <Layout>
      {<ActionBar />}
      {permissions && <PermissionTable permissions={permissions} />}
    </Layout>
  );
};

export default PermissionsPage;
