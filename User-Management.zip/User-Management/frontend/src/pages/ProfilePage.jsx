import React from "react";
import Layout from "../components/Layout";

const ProfilePage = ({ profileData }) => {
  return (
    <Layout>
      <div className="profile-container">
        <h1 className="profile-heading">Profile</h1>
        <div className="profile-details">
          {profileData ? (
            <>
              <h2>{profileData.name}</h2>
              <p>{profileData.bio}</p>
              {/* Add more profile details here */}
            </>
          ) : (
            <p>Loading...</p>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default ProfilePage;
