// import Header from "../components/Header";
// import RoleTable from "../components/RoleTable";
// import { useLocation } from "react-router-dom";
// const Roles = () => {
//   const location = useLocation();
//   const roles = location.state;
//   return (
//     <div>
//       <Header />
//       <RoleTable roles={roles} />
//     </div>
//   );
// };

// export default Roles;

import React from "react";
import axios from "axios";
import RoleTable from "../components/RoleTable";
import Layout from "../components/Layout";
import ActionBar from "../components/ActionBar";
import { FidgetSpinner } from "react-loader-spinner";
const RolesPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, seterror] = React.useState(null);
  const [roles, setRoles] = React.useState(null);
  const [permissions, setPermissions] = React.useState(null);

  React.useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const response = await axios.get("/roles/all-roles");
        const permissions = await axios.get("/permissions/all-permissions");
        setRoles(response.data);
        setPermissions(permissions.data);
      } catch (err) {
        seterror(err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // const location = useLocation();
  // const permissions = location.state;
  if (loading) {
    return (
      <Layout>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <FidgetSpinner
            visible={true}
            height="80"
            width="80"
            ariaLabel="dna-loading"
            wrapperStyle={{}}
            wrapperClass="dna-wrapper"
            ballColors={["#ff0000", "#00ff00", "#0000ff"]}
            backgroundColor="#F4442E"
          />
        </div>
      </Layout>
    );
  }
  if (error) {
    return <Layout>{error}</Layout>;
  }
  return (
    <Layout>
      {permissions && <ActionBar permissions={permissions} />}
      {roles && <RoleTable roles={roles} />}
    </Layout>
  );
};

export default RolesPage;
