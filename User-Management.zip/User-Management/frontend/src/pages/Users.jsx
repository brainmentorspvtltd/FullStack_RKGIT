import React, { useState, useEffect } from "react";
import axios from "axios";
import UserTable from "../components/UserTable";
import Layout from "../components/Layout";
import ActionBar from "../components/ActionBar";
import { FidgetSpinner } from "react-loader-spinner";

const PermissionsPage = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState(null);
  const [roles, setRoles] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const usersResponse = await axios.get("/users/all-users");
        const rolesResponse = await axios.get("/roles/all-roles");
        setUsers(usersResponse.data);
        setRoles(rolesResponse.data);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <Layout>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <FidgetSpinner
            visible={true}
            height="80"
            width="80"
            ariaLabel="dna-loading"
            wrapperStyle={{}}
            wrapperClass="dna-wrapper"
            ballColors={["#ff0000", "#00ff00", "#0000ff"]}
            backgroundColor="#F4442E"
          />
        </div>
      </Layout>
    );
  }

  if (error) {
    return <Layout>Error: {error.message}</Layout>;
  }

  return (
    <Layout>
      {roles && <ActionBar roles={roles} />}
      {users && <UserTable users={users} />}
    </Layout>
  );
};

export default PermissionsPage;
