import axios from "axios";

const getPermissionsName = async (id) => {
  try {
    const response = await axios.get(`/permissions/get-permission/${id}`);
    console.log(response.data.name);
    return response.data.name;
  } catch (error) {
    
  }
};

export default getPermissionsName;
