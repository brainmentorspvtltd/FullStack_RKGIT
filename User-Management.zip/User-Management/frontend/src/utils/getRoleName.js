import axios from "axios";

const getRoleName = async (id) => {
  try {
    const response = await axios.get(`/roles/get-role/${id}`);
    console.log(response.data.name);
    return response.data.name;
  } catch (error) {
    
  }
};

export default getRoleName;
