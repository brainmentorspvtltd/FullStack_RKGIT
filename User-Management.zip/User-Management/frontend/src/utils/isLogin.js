import axios from "axios";

const checkLogin = async () => {
  try {
    const response = await axios.get("/users/check-login");
    return response.status === 200;
  } catch (error) {
    return false;
  }
};

const isLogin = checkLogin();

export default isLogin;
