const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    executablePath: "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
    headless: false,
  });

  const page = await browser.newPage();

  try {
    // Navigate to WhatsApp Web
    await page.goto('https://web.whatsapp.com/');
    
    // Wait for the initial page load using domcontentloaded event
    await page.waitForNavigation({ waitUntil: 'domcontentloaded' });

    // Wait for user to scan the QR code and log in
    await page.waitForSelector('._3H4MS', { visible: true, timeout: 60000 }); // Increased timeout to 60 seconds

    // Extract data from all span tags
    const extractedData = await page.evaluate(() => {
      const spanElements = document.querySelectorAll('span._11JPr.selectable-text.copyable-text > span');
      const data = [];

      spanElements.forEach(spanElement => {
        const textContent = spanElement.textContent.trim();
        data.push(textContent);
      });

      return data;
    });

    // Print the extracted data
    console.log(extractedData);
  } catch (error) {
    console.error("An error occurred:", error);
  } finally {
    // Close the browser
    await browser.close();
  }
})();
