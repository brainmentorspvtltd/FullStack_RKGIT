import React from "react";
import {One} from './components/One';
const App = ()=>{
  return (<div>
    <h1>Hello react js</h1>
    <h2>hi React js</h2>
    <br/>
  <One/>
  </div>)
  //return (<h1>Hello React JS</h1><h2>Hi React </h2>);
  //return {children:[{},{}]};
  // return React.createElement('div'
  // , null,
  // React.createElement('h1',null,'Hello React JS....'),
  //  React.createElement('h1',null,'Hi React JS....')); 
  
}
export default App;