export const One = ()=>{
    const time = 10; // 24
    const fruits = ['Apple', 'Mango', 'Orange'];
    const add = ()=>{
        return "I am the Add Contains the Logic ";
    }

    const title = "One Component...";
    return (
      <> 
      Fruits are 
      <ul>
        {fruits.map((fruit,index)=>
        <li key={index}>{fruit}</li>)}
      </ul>
      {time>12?"PM":"AM"}
    <h3>I am the {title} Contains the JSX</h3>
    Add is {add()}
    </>
    )
}