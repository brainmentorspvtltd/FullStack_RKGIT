export const List = (props)=>{
    return (<div>
        <h1>{props.note.id} {props.note.title} {props.note.descr}</h1>
    </div>)
}