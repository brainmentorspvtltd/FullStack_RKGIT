import { useState } from "react";
import { Header } from "../../../shared/components/Header"
import { Add } from "../components/Add"
import { List } from "../components/List"
import Container from '@mui/material/Container';

export const NotePage = ()=>{
    console.log('Note Page Call');
    const [value, setValue] = useState({});
    const collectNoteData = (noteObject)=>{
        setValue(noteObject);
        console.log('Rec data from Add ', noteObject, ' ');
    }
    return (<Container fixed>
        <Header/>
        <Add fn = {collectNoteData}/>
        <List note = {value}/>
        </Container>)
}