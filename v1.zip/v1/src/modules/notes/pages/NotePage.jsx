import { Add } from "../components/Add"
import { List } from "../components/List"

export const NotePage = ()=>{
    return (<div>
        <h1>Note Page</h1>
        <Add/>
        <List/>
    </div>)
}