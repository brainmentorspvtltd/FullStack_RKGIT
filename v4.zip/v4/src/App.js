import logo from './logo.svg';
import './App.css';
import { NotePage } from './modules/notes/pages/NotePage';
import { DashBoard } from './modules/dashboard/pages/DashBoard';
import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
    <DashBoard/>
    </BrowserRouter>
  );
}

export default App;
