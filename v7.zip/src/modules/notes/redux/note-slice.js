import { createSlice } from "@reduxjs/toolkit";

const noteSlice = createSlice({
    name:'noteslice',
    initialState:{'notes':[], 'total':0},
    reducers:{
        // CRUD Operations
        // Sync Operations 
        // action - coming from the component 
        // state - update the centeralized store.
        addNote(state, action){
            const noteObject = action.payload;
            console.log('Add Note Reducer Operation Called.... ', action.payload);
            state.notes.push(noteObject);
            
        },
        getTotalRecords(state, action){
            state.total = state.notes.length;
        },
        removeNote(state, action){

        },
        searchNote(state, action){

        },
        sortNote(state, action){

        }
    },
    extraReducers:{
        // Async Operations
    }
});
export const {addNote, removeNote, getNote,getTotalRecords} =  noteSlice.actions; // Component
export default  noteSlice.reducer;